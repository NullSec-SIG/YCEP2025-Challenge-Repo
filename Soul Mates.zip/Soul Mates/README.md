
# Soul Mates
White has checkmate in 2 moves. Can you find it?
flag format: YCEP25{whitemove_blackmove_whitemove}
example: YCEP25{rf1_kb2_qh3}


## Summary
- **Author:** Ryan
- **Category:** misc
- **Difficulty:** medium
- **Discord:** protato0778

## Hints
None

## Files
- [board.png](<dist/board.png>)

## Flags
- `YCEP25{bh1_kxa2_qg2#}` (static, case-sensitive)

## Services
None
