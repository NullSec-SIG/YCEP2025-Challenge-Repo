go to chess.com analysis to find out the moves for mate in 2
bh1_kxa2_qg2#