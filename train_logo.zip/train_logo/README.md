
# train_logo
This is a practice challenge that will be gone through during the workshop.


## Summary
- **Author:** Jun Wei
- **Category:** forensics
- **Difficulty:** easy
- **Discord:** syn3pz

## Hints
None

## Files
- [nullsec.png](<dist/nullsec.png>)

## Flags
- `YCEP25{stringing_it}` (static, case-insensitive)

## Services
None
